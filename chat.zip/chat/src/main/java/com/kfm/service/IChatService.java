package com.kfm.service;

import com.kfm.entity.ChatEntity;

public interface IChatService {
    int insert(ChatEntity chat);
}
